package net.ahm.member.profile.service.client;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.lenient;

import java.util.concurrent.ExecutionException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.env.Environment;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import net.ahm.member.profile.service.model.ESLSearchIndividualRequest;
import net.ahm.member.profile.service.model.ESLSearchRequest;
import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
class SearchMemberRestClientTest {

	@Mock
	private WebClient webClient;

	@Mock
	private OAuth2RestTemplate oauthRestTemplate;

	@Mock
	private Environment environment;

	@Mock
	private org.springframework.security.oauth2.common.OAuth2AccessToken accesstoken;

	@InjectMocks
	private SearchMemberRestClient testTarget;

	@Mock
	WebClient.RequestBodyUriSpec requestBodyUriSpec;

	@Mock
	WebClient.RequestHeadersSpec requestHeadersSpec;

	@Mock
	WebClient.RequestBodySpec requestBodySpec;

	@Mock
	WebClient.ResponseSpec responseSpec;

	@BeforeEach
	void setUp() {
		lenient().when(accesstoken.getValue()).thenReturn("ACCESS_TOKEN_VALUE");
		lenient().when(oauthRestTemplate.getAccessToken()).thenReturn(accesstoken);
		lenient().when(webClient.post()).thenReturn(requestBodyUriSpec);
		lenient().when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
		lenient().when(requestBodySpec.header(anyString(), anyString())).thenReturn(requestBodySpec);

		lenient().when(requestHeadersSpec.header(anyString(), anyString())).thenReturn(requestHeadersSpec);

		lenient().when(requestBodySpec.accept(any())).thenReturn(requestBodySpec);
		lenient().when(requestBodySpec.body(any())).thenReturn(requestHeadersSpec);
		lenient().when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
		lenient().when(responseSpec.bodyToMono(ArgumentMatchers.<Class<String>>notNull()))
				.thenReturn(Mono.just("resp"));
	}

	@Test
	void Get_Api_Response_Happy_Path() throws ExecutionException, InterruptedException {
		ESLSearchIndividualRequest individualRequest = new ESLSearchIndividualRequest();
		individualRequest.setxCVSConsumerCorrelationId("CORRELATION_ID");
		individualRequest.setIndividualSearch(new ESLSearchRequest());
		assertThrows(java.lang.NullPointerException.class, () -> testTarget.getAPIResponse(individualRequest));
	}
}