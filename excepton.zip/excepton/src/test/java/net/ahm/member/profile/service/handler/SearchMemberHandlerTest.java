package net.ahm.member.profile.service.handler;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import net.ahm.member.profile.service.client.SearchMemberRestClient;
import net.ahm.member.profile.service.model.CrosswalkSearchRequest;
import net.ahm.member.profile.service.model.CrosswalkSearchResponse;
import net.ahm.member.profile.service.model.ESLIdentifierResponse;
import net.ahm.member.profile.service.model.ESLIndividualIdentifierResponse;
import net.ahm.member.profile.service.model.ESLIndividualSearchResponse;
import net.ahm.member.profile.service.model.ESLSearchIndividualRequest;
import net.ahm.member.profile.service.model.ESLSearchResponse;
import net.ahm.member.profile.service.model.ESLSourceSystemIdentfierResponse;
import net.ahm.member.profile.service.model.ESLSourceSystemIdentifierRequest;
import net.ahm.member.profile.service.model.ESLSourceSystemIdividualResponse;
import net.ahm.member.profile.service.model.MemberStatusRec;

@ExtendWith(MockitoExtension.class)
public class SearchMemberHandlerTest {

	@Mock
	private ESLSourceSystemIdentifierRequest sourceSystemIdentifierMock;

	@Mock
	private ESLIndividualIdentifierResponse individualGlobalId;

	@InjectMocks
	private SearchMemberHandler testTarget;

	@Mock
	private SearchMemberRestClient eslRestClient;

	private final static String idValue = "ID Value";

	@BeforeEach
	public void setUp() throws Exception {
		ESLSearchResponse response = new ESLSearchResponse();
		response.setHttpCode("200");
		response.setHttpMessage("SUCCESSFULL REQUEST");
		lenient().when(eslRestClient.getAPIResponse(any(ESLSearchIndividualRequest.class))).thenReturn(response);
	}

	@Test
	public void Find_Member_Plan_Id() throws Exception {
		testTarget.setidsource("~CVSH");
		CrosswalkSearchRequest cwRequest = new CrosswalkSearchRequest();
		cwRequest.setidType("DigitalID");
		cwRequest.setidValue(idValue);
		CrosswalkSearchResponse crosswalkSearchResponse = testTarget.findMemPlanId(cwRequest);
		assertNotNull(crosswalkSearchResponse);
		assertEquals(10010, (int) ((MemberStatusRec) crosswalkSearchResponse.getStatusRec()).getstatusCode());

		cwRequest.setidType("AH");
		cwRequest.setidValue(idValue);
		crosswalkSearchResponse = testTarget.findMemPlanId(cwRequest);
		assertNotNull(crosswalkSearchResponse);
		assertEquals(10010, (int) ((MemberStatusRec) crosswalkSearchResponse.getStatusRec()).getstatusCode());
	}

	@Test
	public void Find_Member_Plan_Id_ThrowsException() throws Exception {
		CrosswalkSearchRequest cwRequest = new CrosswalkSearchRequest();
		cwRequest.setidType(null);
		cwRequest.setidValue(null);
		assertThrows(NullPointerException.class, () -> testTarget.findMemPlanId(cwRequest));
	}

	@Test
	public void Find_Member_Plan_Id_HappyPath() throws Exception {
		testTarget.setidsource("CVSH");
		ESLIdentifierResponse eslIdentifierResponse = new ESLIdentifierResponse();
		eslIdentifierResponse.setresourceId("CVSH~4700041162056419959");
		ESLSourceSystemIdentfierResponse identfierResponse = new ESLSourceSystemIdentfierResponse();
		identfierResponse.setIndividualIdentifier(eslIdentifierResponse);
		ArrayList<ESLSourceSystemIdentfierResponse> srcSystemResponse = new ArrayList<ESLSourceSystemIdentfierResponse>();
		srcSystemResponse.add(identfierResponse);
		ESLSourceSystemIdividualResponse idividualResponse = new ESLSourceSystemIdividualResponse();
		idividualResponse.setSourceSystemIndividual(srcSystemResponse);
		ESLIndividualSearchResponse searchResponse = new ESLIndividualSearchResponse();
		searchResponse.addIndividualItem(idividualResponse);
		ESLSearchResponse response = new ESLSearchResponse();
		response.setIndividualList(searchResponse);
		response.setHttpMessage("SUCCESSFULL REQUEST");
		lenient().when(eslRestClient.getAPIResponse(any(ESLSearchIndividualRequest.class))).thenReturn(response);

		CrosswalkSearchRequest cwRequest = new CrosswalkSearchRequest();
		cwRequest.setidType("DigitalID");
		cwRequest.setidValue(idValue);
		CrosswalkSearchResponse crosswalkSearchResponse = testTarget.findMemPlanId(cwRequest);
		assertNotNull(crosswalkSearchResponse);
		assertEquals(10000, (int) ((MemberStatusRec) crosswalkSearchResponse.getStatusRec()).getstatusCode());
	}
}