package net.ahm.member.profile.service.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import net.ahm.member.profile.service.handler.SearchMemberHandler;
import net.ahm.member.profile.service.model.CrosswalkSearchRequest;
import net.ahm.member.profile.service.model.CrosswalkSearchResponse;
import net.ahm.member.profile.service.model.MemberStatusRec;
import net.ahm.member.profile.service.utils.MemberConstants;

@ExtendWith(MockitoExtension.class)
public class IndividualSearchTest {

	@Mock
	private SearchMemberHandler searchMemberHandler;

	@InjectMocks
	private IndividualSearch testTarget;

	@Mock
	private HttpServletRequest httpServletRequest;

	@BeforeEach
	public void setUp() {
	}

	@Test
	public void SearchMember_Happy_Path() throws Exception {
		testTarget.setserverEnv("ENVIRONMENT_STRING");
		HttpHeaders headers = new HttpHeaders();
		headers.add(MemberConstants.X_CORRELATION_ID, "12312345");
		headers.add(MemberConstants.CLIENT_APP, "CE");
		ResponseEntity<CrosswalkSearchResponse> searchResponse = testTarget.getMem(headers, httpServletRequest,
				"IdValue", "DigitalID", "AH");
		assertNotNull(searchResponse);
		verify(searchMemberHandler, times(1)).findMemPlanId(any(CrosswalkSearchRequest.class));
	}

	@Test
	public void SearchMember_Empty_Headers() throws Exception {
		HttpHeaders headers = new HttpHeaders();
		headers.add(MemberConstants.X_CORRELATION_ID, null);
		headers.add(MemberConstants.CLIENT_APP, "CE");
		ResponseEntity<CrosswalkSearchResponse> searchResponse = testTarget.getMem(headers, httpServletRequest,
				"IdValue", "DigitalID", "AH");
		assertNotNull(searchResponse);
		MemberStatusRec memberStatusRec = searchResponse.getBody().getStatusRec();
		assertEquals(412, memberStatusRec.getstatusCode());
		assertEquals("Mandatory elements not found in http headers", memberStatusRec.getstatusDesc());
	}

	@Test
	public void SearchMember_Empty_CrossWalkRequest() throws Exception {
		HttpHeaders headers = new HttpHeaders();
		headers.add(MemberConstants.X_CORRELATION_ID, "12312345");
		headers.add(MemberConstants.CLIENT_APP, "CE");
		ResponseEntity<CrosswalkSearchResponse> searchResponse = testTarget.getMem(headers, httpServletRequest, null,
				null, "Search Scope");
		assertNotNull(searchResponse);
		MemberStatusRec memberStatusRec = searchResponse.getBody().getStatusRec();
		assertEquals(10040, memberStatusRec.getstatusCode());
		assertEquals("Invalid data in the request", memberStatusRec.getstatusDesc());
	}

	@Test
	public void GetDecryptedData_Unable_Process() throws IOException {
		testTarget.setserverEnv("PRODPRD");
		HttpHeaders headers = new HttpHeaders();
		String decyptedData = testTarget.getDecyptedData(headers, "DATA_TO_ENCRYPT", "ENCRYPTED_DATA_TO_DECRYPT");
		assertEquals(MemberConstants.STATUS_DECRYPT, decyptedData);
	}

}
