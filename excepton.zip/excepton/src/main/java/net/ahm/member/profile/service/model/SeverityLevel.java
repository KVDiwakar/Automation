package net.ahm.member.profile.service.model;

public enum SeverityLevel {
	LOW {
		@Override
		public String toString() {
			return "Low";
		}
	},
	MED {
		@Override
		public String toString() {
			return "Med";
		}
	},
	HIGH {
		@Override
		public String toString() {
			return "High";
		}
	}
}
