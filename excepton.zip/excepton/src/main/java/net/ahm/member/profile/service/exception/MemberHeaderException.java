package net.ahm.member.profile.service.exception;

public class MemberHeaderException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public MemberHeaderException(String errorMessage) {  
	    super(errorMessage);  
	    }  

}
