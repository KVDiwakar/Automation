package net.ahm.member.profile.service.handler;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
import net.ahm.member.profile.service.dao.MemberDemographicDAO;
import net.ahm.member.profile.service.model.MemberDemographicSearchResponse;
import net.ahm.member.profile.service.model.MemberStatus;
import net.ahm.member.profile.service.utils.MemberConstants;

@Component
@Scope("prototype")
@Slf4j
public class MemberDemographicHandler {

	@Autowired
	private DataSource ds;

	@Autowired
	MemberDemographicDAO dao;

	public MemberDemographicSearchResponse processAction(String correlationID, long memberId) throws SQLException {

		MemberDemographicSearchResponse response = null;
		Connection con = null;

		try {

			con = ds.getConnection();

			response = dao.process(correlationID , memberId, con);

		} catch (Exception e) {
			MemberStatus memberStatusRec = new MemberStatus();
			memberStatusRec.setStatusCode(10004);
			memberStatusRec.setStatusDesc(MemberConstants.STATUS_10004);
			response.setStatusRec(memberStatusRec);
			log.error ("X-Correlation-Id: " + correlationID + " | "+e.getMessage()+" | MemberPlanId:  " + memberId);
			if (null != con && !con.isClosed()) {
				con.rollback();
				con.close();// this will put connection back in
							// pool.
			}
			throw e;
		} finally {
			// this will handle other errors
			if (null != con && !con.isClosed()) {
				con.rollback();
				con.close();// this will put connection back in
							// pool.
			}
		}

		return response;
	}
}
