package net.ahm.member.profile.service.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(Include.NON_NULL)
//
public class CrosswalkSearchRequest {

	@JsonProperty("idValue")
	private String idValue;

	@JsonProperty("idType")
	private String idType;

	@JsonProperty("searchScope")
	private String searchScope;

	private String xCorrelationId;

	public String getsearchScope() {
		return this.searchScope;
	}

	public String getidType() {
		return this.idType;
	}

	public String getidValue()

	{
		return this.idValue;
	}

	public String getxCorrelationId() {
		return this.xCorrelationId;
	}

	public void setsearchScope(String searchScope) {
		this.searchScope = searchScope;
	}

	public void setidType(String idType) {
		this.idType = idType;
	}

	public void setidValue(String idValue)

	{
		this.idValue = idValue;
	}

	public void setxCorrelationId(String xCorrelationId) {
		this.xCorrelationId = xCorrelationId;
	}

	@Override
	public String toString() {
		return "{ SourceSystem: " + searchScope + ", idType: " + idType + ", idValue: " + idValue + ", xCorrelationId: "
				+ xCorrelationId + " }";

	}

}
