package net.ahm.member.profile.service.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
//@JsonInclude(JsonInclude.Include.NON_NULL)
public class MemberInfoMap {
	
	@JsonProperty("FIRSTNAME")
	 private String firstName;
	@JsonProperty("LASTNAME")
     private String lastName;
	 @JsonProperty("MEMBERPLANID")
     private long memberPlanId;
	 @JsonProperty("MEMBERADDRESS1")
     private String address1;
	 @JsonProperty("MEMBERADDRESS2")
     private String address2;
	 @JsonProperty("MEMBERCITY")
     private String city;
	 @JsonProperty("MEMBERSTATE")
     private String state;
	 @JsonProperty("MEMBERCOUNTRY")
     private String country;
	 @JsonProperty("MEMBERPOSTALCODE")
     private String postalCode;
	 @JsonFormat(pattern="MM-dd-yyyy")
	 @JsonProperty("MEMBERDOB")
     private String dob;
	 @JsonProperty("MEMBERGENDER")
     private String gender;
	 @JsonProperty("CLIENTNAME")
     private String clientName;
	 @JsonProperty("MASTERSUPPLIERNAME")
     private String masterSupplierName;
	 @JsonProperty("MASTERSUPPLIERID")
     private int masterSupplierId;
	 @JsonProperty("SUPPLIERNAME")
     private String supplierName;
	 @JsonProperty("SUPPLIERID")
     private int supplierId;
	 @JsonFormat(pattern="MM-dd-yyyy")
	 @JsonProperty("MEMBEREFFECTIVEDATE")
     private String effectiveDate;
	 @JsonProperty("ELIGIBILITYTERMINATIONDATE")
     private String terminationDate;
	 @JsonProperty("HOMEPHONENUMBER")
     private String homePhoneNumber;
	 @JsonProperty("WORKPHONENUMBER")
     private String workPhoneNumber;
	 @JsonProperty("PHONEEXTENSION")
     private String phoneExtension;
	 @JsonProperty("FAX")
     private String fax;
	 @JsonProperty("EMAIL")
     private String email;
	 @JsonProperty("RACE")
     private String race;
	 @JsonProperty("MIDDLEINITIAL")
     private String middleInitial;
	 @JsonProperty("NAMESUFFIX")
     private String nameSuffix;
	 @JsonProperty("RELATIONSHIPID")
     private String relationshipId;
	 @JsonProperty("PLANID")
     private int planId;
	
	}


