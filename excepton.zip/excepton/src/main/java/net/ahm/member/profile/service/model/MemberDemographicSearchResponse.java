package net.ahm.member.profile.service.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
//@JsonInclude(JsonInclude.Include.NON_NULL)
public class MemberDemographicSearchResponse {

	private MemberInfo memberInfo;
	private MemberStatus statusRec;

	public void setStatusRec(MemberStatus memberStatus) {
		this.statusRec = memberStatus;
	}

	public MemberStatus getStatusRec() {
		return this.statusRec;
	}

	public MemberDemographicSearchResponse() {
	}

	@Override
	public String toString() {
		return "MemberDemographicSearchResponse [memberInfo=" + memberInfo + ", statusRec=" + statusRec + "]";
	}
	

}
