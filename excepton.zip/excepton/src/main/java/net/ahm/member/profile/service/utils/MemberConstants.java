package net.ahm.member.profile.service.utils;

public class MemberConstants {
	public static final String AETNA_PROXY_PORT = "${infra.proxy.port}";
	public static final String AETNA_PROXY_HOST = "${infra.proxy.host}";
	public static final String SERVER_ENV = "${infra.server.env}";

	public static final String ESC_CHAR_START = "\"";
	public static final String ESC_CHAR_END = "\";";
	public static final String SEMI_COLON = ";";
	public static final String COLON_SYMBOL = ":";
	public static final String COMMA_SPACE_REGX = " , ";
	public static final String SECRET_KEY = " password=";
	public static final String USERNAME_KEY = " username=";

	public static final String CVS_ESL_EPH_API = "cvs-esl-eph-api";
	public static final String HTTPS_PROXY_PORT = "https.proxyPort";
	public static final String HTTPS_PROXY_HOST = "https.proxyHost";
	public final static String DATE_FORMAT = "dd/MM/yyyy";//my change
	public final static String DATE_MIN_VALUE = "01/01/0001";//my change
	public static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
	public static final String PERIOD_SEPERATOR = ".";

	public static final String ESLAPI_URL = "${infra.cvs.eslapi.url}";
	public static final String IDSOURCE = "${infra.cvs.eslapi.idsource}";
	public static final String PATHPARAM_ID = "id";
	public static final String QUERYPARAM_APP_MSG_ID = "appMsgID";
	public static final String QUERYPARAM_VERSION = "version";
	public static final String QUERYPARAM_MSGDATETIMESTAMP = "msgDateTimestamp";
	public static final String QUERYPARAM_MAINTENANCEREQUESTID = "maintenanceRequestID";
	public static final String QUERYPARAM_LASTUPDATEDTIME = "lastUpdatedTime";
	public static final String QUERYPARAM_EFFECTIVEDATE = "effectiveDate";
	public static final String QUERYPARAM_TERMDATE = "termDate";

	public static final String ESL_OAUTH2_SCOPE = "${infra.cvs.eslapi.oauth2.scope}";
	public static final String ESL_OAUTH2_GRANT_TYPE = "${infra.cvs.eslapi.oauth2.grant.type}";
	public static final String ESL_OAUTH2_CLIENT_SECRET = "${infra.cvs.eslapi.oauth2.client.secret}";
	public static final String ESL_OAUTH2_CLIENT_ID = "${infra.cvs.eslapi.oauth2.client.id}";
	public static final String ESL_OAUTH2_TOKEN_URI = "${infra.cvs.eslapi.oauth2.token.url}";

	public static final String X_CORRELATION_ID = "x-correlation-id";
	public static final String CLIENT_APP = "client-app";

	public static final String X_CVS_CONSUMER_CORRELATION_ID = "x-CVSConsumerCorrelationId";
	public static final String X_CLIENT_CERTIFICATE = "X-Client-Certificate";
	public static final String X_IBM_CLIENT_ID = "X-IBM-Client-Id";
	public static final String REGEX_SPACE = " ";

	public static final String SOURCE_SYSTEM_EPH = "PHR-EPH";

	public static final String APPMSGID = "AHM";

	public static final String EXCLUDE_FLAG = "No";

	public static final String SOURCE = "AH";

	public static final String DATASOURCENM_ESL = "ESL";
	public static final String HTTPSUCCESS = "200";
	public static final String SUCCESS_ESL = "ESL SUCCESS";
	public static final String FAILURE_ESL = "ESL FAILURE";
	public static final long SUCCESS_ODS_MSG_CD = 5000L;
	public static final long FAILURE_ODS_MSG_CD = 3001L;
	public static final long SUCCESS_CODE = 10000;

	public static final String STATUS_10002 = "Mandatory elements not found";
	public static final String STATUS_10004 = "Not successful";
	public static final String STATUS_10040 = "Invalid data in the request";
	public static final String STATUS_10010 = "Member data not found";
	public static final String STATUS_20000 = "Internal application error";
	public static final String STATUS_412 = "Mandatory elements not found in http headers";
	public static final String STATUS_432 = "Invalid appID in http headers";
	public static final String STATUS_NONE = "None";

	public static final String STATUS_DECRYPT = "Unable to process your request!";

	public static final String SECUREUSER = "${infra.ephadapter.secure.user}";
	public static final String SECUREPASSWORD = "${infra.ephadapter.secure.password}";
	
	public static final String MEMBERSECUREUSER = "CaMEligApiService";
	public static final String MEMBERCAMSECUREPASSWORD = "6l#xwr!5$yGK7FvazL4Y";

	public static final String PROXYENABLED = "${infra.proxy.enabled}";

	public static final String PERF_METRIC_ESL = "ESL_";
	public static final String ENCRYPTION_KEY = "infra.encryption.key";
	public static final String BLOCK_CIPHER = "infra.iv.spec";
	public static final String AES = "AES";
	public static final String AES_GCM_NO_PADDING = "AES/GCM/NoPadding";
	public static final String DES_PREFIX = "ENC2(";
	public static final String AES_PREFIX = "ENC(";
	public static final String APP_HOME_DIR = "APP_HOME_DIR";
	public static final String LOGS_PID_FILE = "/logs/pid.file";

	public static final String AHM_ID = "AH";
	public static final String DIGITAL_ID = "DigitalID";

	public static final String ESB_CANONICAL_MESSAGE_ID_STRING = "esbCanonicalMessageID";
	public static final int HTTP_BAD_REQUEST = 400;
	public static final int DATA_VALIDATION_FAILURE = 422;
	public static final int HTTP_MEMBER_NOT_FOUND = 404;
	public static final int HTTP_SUCCESS = 200;
	public static final int HTTP_INTERNAL = 500;

	private MemberConstants() {

	}

}
