package net.ahm.member.profile.service.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ESLIndividualSearchRequest {

	@JsonProperty("searchType")
	private String searchType = null;

	@JsonProperty("searchSourceSystem")
	private List<String> searchSourceSystem = null;

	@JsonProperty("returnType")
	private String returnType = null;

	@JsonProperty("sourceSystemIdentifierSearch")
	private ESLSourceSystemIdentifierRequest sourceSystemIdentifierSearch = null;

	public ESLIndividualSearchRequest searchType(String searchType) {
		this.searchType = searchType;
		return this;
	}

	/**
	 * preferred SearchType
	 * 
	 * @return SearchType
	 **/
	// (value = "preferred global id -- idvalue only.")
	public String getSearchType() {
		return searchType;
	}

	public void setsearchType(String searchType) {
		this.searchType = searchType;
	}

	public ESLIndividualSearchRequest searchSourceSystem(List<String> searchSourceSystem) {
		this.searchSourceSystem = searchSourceSystem;
		return this;
	}

	public ESLIndividualSearchRequest addSearchSourceSystemItem(String searchSourceSystemItem) {
		if (this.searchSourceSystem == null) {
			this.searchSourceSystem = new ArrayList<>();
		}
		this.searchSourceSystem.add(searchSourceSystemItem);
		return this;
	}

	/**
	 * Get searchSourceSystem
	 * 
	 * @return searchSourceSystem
	 **/

	public List<String> getSearchSourceSystem() {
		return searchSourceSystem;
	}

	public void setSearchSourceSystem(List<String> searchSourceSystem) {
		this.searchSourceSystem = searchSourceSystem;
	}

	public ESLIndividualSearchRequest returnType(String returnType) {
		this.returnType = returnType;
		return this;
	}

	/**
	 * filteringOption to filter search result. valid value: KEY, ALL,
	 * GLOBAL_ID. default to ALL KEY -- the search will return Source System
	 * Key, preferred global ID and alternate global ID/s. ALL -- In addition
	 * what are returned with Key option, the search will return demorgraphics
	 * GLOBAL_ID -- return global id only.
	 * 
	 * @return returnType
	 **/
	// (value = "filteringOption to filter search result. valid value: KEY, ALL,
	// GLOBAL_ID. default to ALL KEY -- the search will return Source System
	// Key, preferred global ID and alternate global ID/s. ALL -- In addition
	// what are returned with Key option, the search will return demorgraphics
	// GLOBAL_ID -- return global id only.")
	public String getReturnType() {
		return returnType;
	}

	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}

	public ESLIndividualSearchRequest sourceSystemIdentifierSearch(
			ESLSourceSystemIdentifierRequest sourceSystemIdentifierSearch) {
		this.sourceSystemIdentifierSearch = sourceSystemIdentifierSearch;
		return this;
	}

	/**
	 * Get sourceSystemIdentifierSearch
	 * 
	 * @return sourceSystemIdentifierSearch
	 **/

	public ESLSourceSystemIdentifierRequest getSourceSystemIdentifierSearch() {
		return sourceSystemIdentifierSearch;
	}

	public void setSourceSystemIdentifierSearch(ESLSourceSystemIdentifierRequest sourceSystemIdentifierSearch) {
		this.sourceSystemIdentifierSearch = sourceSystemIdentifierSearch;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		ESLIndividualSearchRequest eslRequestBody = (ESLIndividualSearchRequest) o;
		return Objects.equals(this.searchType, eslRequestBody.searchType)
				&& Objects.equals(this.searchSourceSystem, eslRequestBody.searchSourceSystem)
				&& Objects.equals(this.returnType, eslRequestBody.returnType)
				&& Objects.equals(this.sourceSystemIdentifierSearch, eslRequestBody.sourceSystemIdentifierSearch);
	}

	@Override
	public int hashCode() {
		return Objects.hash(searchType, searchSourceSystem, returnType, sourceSystemIdentifierSearch);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class Individual {\n");

		sb.append("    searchType: ").append(toIndentedString(searchType)).append("\n");
		sb.append("    searchSourceSystem: ").append(toIndentedString(searchSourceSystem)).append("\n");
		sb.append("    returnType: ").append(toIndentedString(returnType)).append("\n");

		sb.append("    sourceSystemIdentifierSearch: ").append(toIndentedString(sourceSystemIdentifierSearch))
				.append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

}
