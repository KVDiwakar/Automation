package net.ahm.member.profile.service.model;



import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MemberInfo {
	
	 private String firstName;
     private String lastName;
     private long memberPlanId;
     private String address1;
     private String address2;
     private String city;
     private String state;
     private String country;
     private String postalCode;
     private String dob;
     private String gender;
     private String clientName;
     private String masterSupplierName;
     private int masterSupplierId;
     private String supplierName;
     private int supplierId;
     private String effectiveDate;
     private String terminationDate;
     private String homePhoneNumber;
     private String workPhoneNumber;
     private String phoneExtension;
     private String fax;
     private String email;
     private String race;
     private String middleInitial;
     private String nameSuffix;
     private String relationshipId;
     private int planId;
	@Override
	public String toString() {
		return "MemberInfo [firstName=" + firstName + ", lastName=" + lastName + ", memberPlanId=" + memberPlanId
				+ ", address1=" + address1 + ", address2=" + address2 + ", city=" + city + ", state=" + state
				+ ", country=" + country + ", postalCode=" + postalCode + ", dob=" + dob + ", gender=" + gender
				+ ", clientName=" + clientName + ", masterSupplierName=" + masterSupplierName + ", masterSupplierId="
				+ masterSupplierId + ", supplierName=" + supplierName + ", supplierId=" + supplierId
				+ ", effectiveDate=" + effectiveDate + ", terminationDate=" + terminationDate + ", homePhoneNumber="
				+ homePhoneNumber + ", workPhoneNumber=" + workPhoneNumber + ", phoneExtension=" + phoneExtension
				+ ", fax=" + fax + ", email=" + email + ", race=" + race + ", middleInitial=" + middleInitial
				+ ", nameSuffix=" + nameSuffix + ", relationshipId=" + relationshipId + ", planId=" + planId + "]";
	}
     
     

}
