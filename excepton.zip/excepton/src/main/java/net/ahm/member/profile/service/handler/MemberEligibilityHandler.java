package net.ahm.member.profile.service.handler;

import java.sql.Connection;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
import net.ahm.member.profile.service.dao.MemberEligibilityDAO;
import net.ahm.member.profile.service.model.MemberEligibilityRequest;
import net.ahm.member.profile.service.model.MemberEligibilityResponse;
import net.ahm.member.profile.service.model.MemberStatus;
import net.ahm.member.profile.service.utils.MemberConstants;

@Component
@Scope("prototype")
@Slf4j
public class MemberEligibilityHandler {

	@Autowired
	private DataSource ds;

	@Autowired
	MemberEligibilityDAO dao;

	public MemberEligibilityResponse processAction(MemberEligibilityRequest memberEligibilityRequest,
			String correlationID) throws Exception {

		

		MemberEligibilityResponse response = null;
		Connection con = null;

		try {

			con = ds.getConnection();

			response = dao.process(memberEligibilityRequest, con, correlationID);

		} catch (Exception e) {
			MemberStatus memberStatusRec = new MemberStatus();
			memberStatusRec.setStatusCode(10004);
			memberStatusRec.setStatusDesc(MemberConstants.STATUS_10004);
			response.setStatusRec(memberStatusRec);
			log.error("X-Correlation-Id: " + correlationID + " | " + e.getMessage());
			if (null != con && !con.isClosed()) {
				con.rollback();
				con.close();// this will put connection back in
							// pool.
			}
			throw e;
		} finally {
			// this will handle other errors
			if (null != con && !con.isClosed()) {
				con.rollback();
				con.close();// this will put connection back in
							// pool.
			}

		}
		

		return response;
	}

}
