package net.ahm.member.profile.service.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ESLSearchRequest {
	@JsonProperty("IndividualSearch")
	private ESLIndividualSearchRequest individualSearch = null;

	public ESLSearchRequest(ESLIndividualSearchRequest individualSearch) {
		this.individualSearch = individualSearch;
	}

	public ESLSearchRequest() {
	}

	/**
	 * Get individual
	 * 
	 * @return individual
	 **/
	public ESLIndividualSearchRequest getIndividualSearch() {
		return individualSearch;
	}

	public void setIndividualSearch(ESLIndividualSearchRequest individualSearch) {
		this.individualSearch = individualSearch;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class IndividualSearch {\n");
		sb.append("    searchType: ").append(toIndentedString(individualSearch)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

}
