package net.ahm.member.profile.service.exception;

import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class MemberHeaderExceptionHandler { 
    @ExceptionHandler(MemberHeaderException.class)
    public String handleException(Exception ex, HttpServletResponse response) {
        response.setStatus(432);
        return ex.getMessage();
    }
    
    @ExceptionHandler(EligibilityException.class)
    public String handleExceptionEligibility(Exception ex, HttpServletResponse response) {
    	
    	response.setStatus(412);
        return ex.getMessage();
    }
}