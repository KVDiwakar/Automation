package net.ahm.member.profile.service.dao;

import java.sql.Clob;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.apache.commons.dbcp2.DelegatingConnection;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
import net.ahm.member.profile.service.model.MemberDemographicSearchResponse;
import net.ahm.member.profile.service.model.MemberInfo;
import net.ahm.member.profile.service.model.MemberInfoMap;
import net.ahm.member.profile.service.model.MemberStatus;
import net.ahm.member.profile.service.utils.EncryptUtils;
import net.ahm.member.profile.service.utils.MemberConstants;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleClob;

@Service
@Scope("prototype")
@Slf4j
public class MemberDemographicDAO {

	private static final String QUERY = "{call ODS.ODS_EpicIntegration.GetMemberDemographicsDetails (?,?,?)}";

	public MemberDemographicSearchResponse process(String correlationID, long memberId, Connection con) {
		OracleCallableStatement ocs = null;
		MemberDemographicSearchResponse response = null;

		System.currentTimeMillis();
		String serviceName = "MemberDemographic";

		try {

			response = new MemberDemographicSearchResponse();
			Connection t4c = ((DelegatingConnection<?>) con).getInnermostDelegate();
			ocs = (OracleCallableStatement) t4c.prepareCall(QUERY);
			ocs.setObject(1, memberId); // memberPlanId
			ocs.registerOutParameter(2, Types.CLOB); // PC_MemberDemographic_OUT

			ocs.registerOutParameter(3, Types.NUMERIC); // PN_RETURNCODE_OUT

			long executeStartTime = System.currentTimeMillis();
			ocs.execute();
			long setResponseStartTime = System.currentTimeMillis();
			log.info(" X-Correlation-Id:" + correlationID + " | " + serviceName
					+ ": stored procedure : running time (millis) = " + (setResponseStartTime - executeStartTime)
					+ " | MemberPlanId:  " + memberId);

			log.info(" X-Correlation-Id:" + correlationID + "| Message: MemberDemographic ODS Return Code : "
					+ ocs.getLong(3) + " | MemberPlanId:  " + memberId);

			long returnCode = ocs.getLong(3);

			if (MemberConstants.SUCCESS_CODE == returnCode) {

				Clob odsClobMemberDetails = (OracleClob) ocs.getClob(2);

				String responseString = odsClobMemberDetails.getSubString(1, (int) odsClobMemberDetails.length());

				log.info("X-Correlation-Id:" + correlationID + " | Response From ODS:"
						+ EncryptUtils.encryptString(responseString) + " | MemberPlanId:  " + memberId);

				ObjectMapper mapper = new ObjectMapper();
				MemberInfoMap memberInfoMap = mapper.readValue(responseString, MemberInfoMap.class);

				MemberInfo memberInfo = MemberInfo.builder().build();

				BeanUtils.copyProperties(memberInfoMap, memberInfo);

				if (StringUtils.isNotEmpty(memberInfoMap.getEffectiveDate())) {
					SimpleDateFormat eDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
					java.util.Date parseet = eDate.parse(memberInfoMap.getEffectiveDate());
					SimpleDateFormat formatEDate = new SimpleDateFormat("MM/dd/yyyy");
					String effectiveDate = formatEDate.format(parseet);

					memberInfo.setEffectiveDate(effectiveDate);

				}
				if (StringUtils.isNotEmpty(memberInfoMap.getTerminationDate())) {
					SimpleDateFormat tDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
					java.util.Date parseet = tDate.parse(memberInfoMap.getTerminationDate());
					SimpleDateFormat formatTDate = new SimpleDateFormat("MM/dd/yyyy");
					String terminationDate = formatTDate.format(parseet);

					memberInfo.setTerminationDate(terminationDate);

				}

				MemberStatus memberStatusRec = new MemberStatus();
				memberStatusRec.setStatusCode(10000);
				memberStatusRec.setStatusDesc("Successful");

				response.setStatusRec(memberStatusRec);

				response.setMemberInfo(memberInfo);
				log.info("X-Correlation-Id: " + correlationID + " | Response Payload:"
						+ EncryptUtils.encryptString(response.toString()) + " | MemberPlanId:  " + memberId);
			} else if (returnCode == 10004) {

				MemberStatus memberStatusRec = new MemberStatus();
				memberStatusRec.setStatusCode(10004);
				memberStatusRec.setStatusDesc(MemberConstants.STATUS_10004);
				response.setStatusRec(memberStatusRec);
				log.info("X-Correlation-Id: " + correlationID + " | Response Payload:"
						+ EncryptUtils.encryptString(response.toString()) + " | MemberPlanId:  " + memberId);

			}

			else {
				response = null;

			}

		} catch (SQLException | ParseException | JsonProcessingException se) {
			MemberStatus memberStatusRec = new MemberStatus();
			memberStatusRec.setStatusCode(10004);
			memberStatusRec.setStatusDesc(MemberConstants.STATUS_10004);
			response.setStatusRec(memberStatusRec);
			log.error(
					" X-Correlation-Id: " + correlationID
							+ "| Message: Error occurred at ODS.ODS_EpicIntegration.GetMemberDemographicsDetails  : ",
					se.getMessage() + " | MemberPlanId:  " + memberId);
		}

		finally {
			try {
				if (ocs != null) {
					ocs.close();
				}
			} catch (SQLException e) {
				log.error(e.getMessage());

			}

		}
		return response;

	}

}
