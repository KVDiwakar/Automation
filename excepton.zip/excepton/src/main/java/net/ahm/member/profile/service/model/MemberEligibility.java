package net.ahm.member.profile.service.model;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
//@JsonSerialize(include = Inclusion.NON_NULL)
public class MemberEligibility {

	private String firstName;
	private String lastName;
	private String MiddleInitial;
	private String nameSuffix;
	private String dob;
	private String gender;
	private long memberPlanId;
	private long planId;
	private long supplierId;
	private String supplierName;
	private String clientName;
	private int masterSupplierId;
	private String masterSupplierName;
	private String city;
	private String state;
	private String effectiveDate;
	private String terminationDate;
	@Override
	public String toString() {
		return "MemberEligibility [firstName=" + firstName + ", lastName=" + lastName + ", MiddleInitial="
				+ MiddleInitial + ", nameSuffix=" + nameSuffix + ", dob=" + dob + ", gender=" + gender
				+ ", memberPlanId=" + memberPlanId + ", planId=" + planId + ", supplierId=" + supplierId
				+ ", supplierName=" + supplierName + ", clientName=" + clientName + ", masterSupplierId="
				+ masterSupplierId + ", masterSupplierName=" + masterSupplierName + ", city=" + city + ", state="
				+ state + ", effectiveDate=" + effectiveDate + ", terminationDate=" + terminationDate + "]";
	}
	


}
