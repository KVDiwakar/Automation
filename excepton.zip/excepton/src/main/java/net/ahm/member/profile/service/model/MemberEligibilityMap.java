package net.ahm.member.profile.service.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
//@JsonSerialize(include = Inclusion.NON_NULL)
public class MemberEligibilityMap {
	
	@JsonProperty("FIRSTNAME")
	private String firstName;
	@JsonProperty("LASTNAME")
	private String lastName;
	@JsonProperty("MIDDLEINITIAL")
	private String MiddleInitial;
	@JsonProperty("NAMESUFFIX")
	private String nameSuffix;
	@JsonProperty("DOB")
	private String dob;
	@JsonProperty("GENDER")
	private String gender;
	@JsonProperty("MEMBERPLANID")
	private long memberPlanId;
	@JsonProperty("PLANID")
	private long planId;
	@JsonProperty("SUPPLIERID")
	private long supplierId;
	@JsonProperty("SUPPLIERNAME")
	private String supplierName;
	@JsonProperty("CLIENTNAME")
	private String clientName;
	@JsonProperty("MASTERSUPPLIERID")
	private int masterSupplierId;
	@JsonProperty("MASTERSUPPLIERNAME")
	private String masterSupplierName;
	@JsonProperty("CITY")
	private String city;
	@JsonProperty("STATE")
	private String state;
	@JsonProperty("EFFECTIVEDATE")
	private String effectiveDate;
	@JsonProperty("TERMINATIONDATE")
	private String terminationDate;

}
