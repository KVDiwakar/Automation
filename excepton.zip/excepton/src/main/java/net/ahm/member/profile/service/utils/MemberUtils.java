package net.ahm.member.profile.service.utils;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class MemberUtils {
	private static final Logger AUTHLOGGER = LoggerFactory.getLogger("authorizationLog");

	private MemberUtils() {
	}

	public static OffsetDateTime getOffsetDateTime(String date) {

		// Truncate milliseconds if its present in the date time
		if (date.indexOf(MemberConstants.PERIOD_SEPERATOR) != -1) {
			date = date.substring(0, date.indexOf(MemberConstants.PERIOD_SEPERATOR));
		}
		DateTimeFormatter dateTimeFormatter = new DateTimeFormatterBuilder().parseCaseInsensitive()
				.append(DateTimeFormatter.ofPattern(MemberConstants.DATE_TIME_FORMAT)).toFormatter();
		LocalDateTime dt = LocalDateTime.parse(date, dateTimeFormatter);
		ZonedDateTime zdt = ZonedDateTime.of(dt, ZoneId.systemDefault());
		return OffsetDateTime.from(zdt);
	}

	public static void logAuthorationInfo(String message) {
		AUTHLOGGER.info(message);
	}

	public static String encryptLog(Environment env, String string) {
		// TODO Auto-generated method stub
		return null;
	}

}
