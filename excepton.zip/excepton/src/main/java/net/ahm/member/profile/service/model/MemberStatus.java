package net.ahm.member.profile.service.model;

public class MemberStatus {
	
	private int statusCode;
	private String statusDesc;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusDesc() {
		return statusDesc;
	}
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	
	public void setStatusRec(int statusCode, String statusDesc) {
		this.setStatusCode(statusCode);
		this.setStatusDesc(statusDesc);
	}

}
