package net.ahm.member.profile.service.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ESLIdentifierResponse {
	@JsonProperty("lastUpdatedTime")
	private String lastUpdatedTime = null;

	@JsonProperty("resourceId")
	private String resourceId = null;

	public String getlastUpdatedTime() {
		return lastUpdatedTime;
	}

	public void setlastUpdatedTime(String lastUpdatedTime) {
		this.lastUpdatedTime = lastUpdatedTime;
	}

	public String getresourceId() {
		return resourceId;
	}

	public void setresourceId(String resourceId) {
		this.resourceId = resourceId;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class Identifier {\n");

		sb.append("    lastUpdatedTime: ").append(toIndentedString(lastUpdatedTime)).append("\n");
		sb.append("    resourceId: ").append(toIndentedString(resourceId)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}
}
