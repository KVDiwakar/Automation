package net.ahm.member.profile.service.model;

import javax.validation.constraints.Max;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
// @JsonInclude(value = Include.NON_NULL)
public class MemberEligibilityRequest {

	@Size(max = 50)
	private String firstName;
	@Size(max = 40)
	private String lastName;
	@Size(max = 1)
	private String middleInitial;
	@Size(max = 10)
	private String nameSuffix;
	private String dob;
	// @Max(1)
	@Size(max = 1)
	private String gender;
	private long memberPlanId;
	private String supplierName;
	@Size(max = 200)
	private String clientName;
	private long supplierId;
	private long planId;
	@Size(max = 50)
	private String city;
	@Size(max = 2)
	private String state;

}
