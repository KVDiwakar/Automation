package net.ahm.member.profile.service.dao;

import java.sql.Clob;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbcp2.DelegatingConnection;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
import net.ahm.member.profile.service.model.MemberEligibility;
import net.ahm.member.profile.service.model.MemberEligibilityMap;
import net.ahm.member.profile.service.model.MemberEligibilityRequest;
import net.ahm.member.profile.service.model.MemberEligibilityResponse;
import net.ahm.member.profile.service.model.MemberStatus;
import net.ahm.member.profile.service.utils.EncryptUtils;
import net.ahm.member.profile.service.utils.MemberConstants;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleClob;

@Service
@Scope("prototype")
@Slf4j
public class MemberEligibilityDAO {
	private static final String QUERY = "{call ODS.ODS_EpicIntegration.GETMEMBERELIGIBILITYDETAILS (?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";

	public MemberEligibilityResponse process(MemberEligibilityRequest request, Connection con, String correlationID)
			throws Exception {

		OracleCallableStatement ocs = null;

		MemberEligibilityResponse response = null;

		String serviceName = "MemberEligibility";

		try {

			response = new MemberEligibilityResponse();
			SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy");

			java.util.Date parse = dt.parse(request.getDob());
			SimpleDateFormat format2 = new SimpleDateFormat("dd-MMM-yyyy");
			String dob = format2.format(parse);

			Connection t4c = ((DelegatingConnection<?>) con).getInnermostDelegate();
			ocs = (OracleCallableStatement) t4c.prepareCall(QUERY);
			ocs.setString(1, request.getFirstName()); // PV_FIRSTNM_IN
			ocs.setString(2, request.getLastName()); // PV_LASTNM_IN
			ocs.setObject(3, dob); // PD_DOB_IN
			if (StringUtils.isNotEmpty(request.getGender())) {
				ocs.setString(4, request.getGender()); // "PV_GENDER_IN
			} else {
				ocs.setNull(4, Types.NULL);
			}
			if (request.getMemberPlanId() > 0) {

				ocs.setLong(5, request.getMemberPlanId()); // PN_MEMBERPLANID_IN
			} else {
				ocs.setNull(5, Types.NULL);
			}

			if (StringUtils.isNotEmpty(request.getClientName())) {
				ocs.setString(6, request.getClientName()); // "PV_CLIENTNM_IN
			} else {
				ocs.setNull(6, Types.NULL);
			}

			if (request.getSupplierId() > 0) {

				ocs.setLong(7, request.getSupplierId()); // PN_SUPPLIERID_IN
			} else {
				ocs.setNull(7, Types.NULL);
			}

			if (request.getPlanId() > 0) {

				ocs.setLong(8, request.getPlanId()); // PN_PLANID_IN
			} else {
				ocs.setNull(8, Types.NULL);
			}

			if (StringUtils.isNotEmpty(request.getMiddleInitial())) {
				ocs.setString(9, request.getMiddleInitial()); // "PV_MIDDLENM_IN
			} else {
				ocs.setNull(9, Types.NULL);
			}

			if (StringUtils.isNotEmpty(request.getNameSuffix())) {
				ocs.setString(10, request.getNameSuffix()); // PV_SUFFIX_IN
			} else {
				ocs.setNull(10, Types.NULL);
			}

			if (StringUtils.isNotEmpty(request.getCity())) {
				ocs.setString(11, request.getCity()); // PV_CITY_IN
			} else {
				ocs.setNull(11, Types.NULL);
			}

			if (StringUtils.isNotEmpty(request.getState())) {
				ocs.setString(12, request.getState()); // PV_STATE_IN
			} else {
				ocs.setNull(12, Types.NULL);
			}

			ocs.registerOutParameter(13, Types.CLOB); // PC_MBRELIGIBILITYDETAILS_OUT
			ocs.registerOutParameter(14, Types.NUMERIC); // PN_RETURNCODE_OUT

			long executeStartTime = System.currentTimeMillis();
			ocs.execute();

			long setResponseStartTime = System.currentTimeMillis();
			log.info("X-Correlation-Id: " + correlationID + " | " + serviceName
					+ ": stored procedure : running time (millis) = " + (setResponseStartTime - executeStartTime));

			log.info(("X-Correlation-Id: " + correlationID + " | Message: MemberEligibility ODS Return Code : "
					+ ocs.getLong(14)));

			long returnCode = ocs.getLong(14);

			// updated to commit/rollback
			if (MemberConstants.SUCCESS_CODE == returnCode) {

				Clob odsClobMemberEligibilityDetails = (OracleClob) ocs.getClob(13);

				String responseString = odsClobMemberEligibilityDetails.getSubString(1,
						(int) odsClobMemberEligibilityDetails.length());
				log.info(("X-Correlation-Id: " + correlationID + " | Response From ODS:"
						+ EncryptUtils.encryptString(responseString)));

				String subString1 = StringUtils.substringBetween(responseString, "[", "]");

				ObjectMapper mapper = new ObjectMapper();
				MemberEligibilityMap memberEligibilitymap = mapper.readValue(subString1, MemberEligibilityMap.class);
				MemberEligibility memberEligibility = MemberEligibility.builder().build();

				BeanUtils.copyProperties(memberEligibilitymap, memberEligibility);

				if (StringUtils.isNotEmpty(memberEligibilitymap.getEffectiveDate())) {
					SimpleDateFormat eDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
					java.util.Date parseet = eDate.parse(memberEligibilitymap.getEffectiveDate());
					SimpleDateFormat formatEDate = new SimpleDateFormat("MM/dd/yyyy");
					String effectiveDate = formatEDate.format(parseet);

					memberEligibility.setEffectiveDate(effectiveDate);

				}
				if (StringUtils.isNotEmpty(memberEligibilitymap.getTerminationDate())) {
					SimpleDateFormat tDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
					java.util.Date parseet = tDate.parse(memberEligibilitymap.getTerminationDate());
					SimpleDateFormat formatTDate = new SimpleDateFormat("MM/dd/yyyy");
					String terminationDate = formatTDate.format(parseet);

					memberEligibility.setTerminationDate(terminationDate);

				}
				List<MemberEligibility> memberEligibilitylist = new ArrayList<>();

				memberEligibilitylist.add(memberEligibility);

				MemberStatus memberStatusRec = new MemberStatus();
				memberStatusRec.setStatusCode(10000);
				memberStatusRec.setStatusDesc("Successful");
				response.setMemberEligibility(memberEligibilitylist);
				response.setStatusRec(memberStatusRec);
				log.info(("X-Correlation-Id: " + correlationID + " | Response Payload:"
						+ EncryptUtils.encryptString(response.toString())));

				con.commit();
			} else if (returnCode == 10004) {

				MemberStatus memberStatusRec = new MemberStatus();
				memberStatusRec.setStatusCode(10004);
				memberStatusRec.setStatusDesc(MemberConstants.STATUS_10004);
				response.setStatusRec(memberStatusRec);
				log.info(("X-Correlation-Id: " + correlationID + " | Response Payload:"
						+ EncryptUtils.encryptString(response.toString())));

			}

			else {
				response = null;
			}
		} catch (SQLException se) {
			MemberStatus memberStatusRec = new MemberStatus();
			memberStatusRec.setStatusCode(10004);
			memberStatusRec.setStatusDesc(MemberConstants.STATUS_10004);
			response.setStatusRec(memberStatusRec);
			log.error(
					" X-Correlation-Id: " + correlationID
							+ "| Message: Error occurred at ODS.ODS_EpicIntegration.GetMemberDemographicsDetails  : ",
					se.getMessage());
		}

		finally {
			try {
				if (ocs != null) {
					ocs.close();
				}
			} catch (SQLException e) {
				log.error(e.getMessage());
				throw e;
			}

		}
		return response;
	}

}
