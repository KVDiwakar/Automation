package net.ahm.member.profile.service;

import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.ApplicationPidFileWriter;

import com.nimbusds.oauth2.sdk.util.StringUtils;

import lombok.extern.slf4j.Slf4j;
import net.ahm.member.profile.service.utils.EncryptUtils;
import net.ahm.member.profile.service.utils.MemberConstants;

@SpringBootApplication
@Slf4j
public class MemberApplication {
	

	public static void main(String[] args) {
		SpringApplication springApplication = new SpringApplication(MemberApplication.class);
		
		String a = EncryptUtils.encryptString("AHmm#$4929");
		
	System.out.println(a);
	
	String b = EncryptUtils.decryptString(a);
	
	System.out.println(b);
	
		springApplication.addListeners(new ApplicationPidFileWriter(
				System.getenv(MemberConstants.APP_HOME_DIR) + MemberConstants.LOGS_PID_FILE));
		springApplication.run(args);
	}
	

	@PreDestroy
	void shutDown() {
		log.debug("## MemberServiceApplication ShutDown ###");
	}
}
