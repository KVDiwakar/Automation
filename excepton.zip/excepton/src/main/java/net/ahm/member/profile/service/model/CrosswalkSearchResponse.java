package net.ahm.member.profile.service.model;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CrosswalkSearchResponse {

	@JsonProperty("memberResponse")
	ArrayList<Long> memberResponse;

	@JsonProperty("statusRec")
	private MemberStatusRec statusRec;

	public CrosswalkSearchResponse() {
		this.memberResponse = new ArrayList<>();
		this.statusRec = new MemberStatusRec();
	}

	public MemberStatusRec showMemberStatus() {
		return statusRec;
	}

	public void setStatusRec(int statusCode, String statusDesc) {
		this.statusRec.setStatusRec(statusCode, statusDesc);
	}

	public void setPlanid(long planid) {
		this.memberResponse.add(planid);
	}

	public MemberStatusRec getStatusRec() {
		return this.statusRec;
	}
}
