package net.ahm.member.profile.service.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;
import net.ahm.member.profile.service.exception.MemberHeaderException;
import net.ahm.member.profile.service.exception.EligibilityException;
import net.ahm.member.profile.service.handler.MemberDemographicHandler;
import net.ahm.member.profile.service.handler.MemberEligibilityHandler;
import net.ahm.member.profile.service.model.AuthorizationLogElements;
import net.ahm.member.profile.service.model.MemberDemographicSearchResponse;
import net.ahm.member.profile.service.model.MemberEligibilityRequest;
import net.ahm.member.profile.service.model.MemberEligibilityResponse;
import net.ahm.member.profile.service.model.MemberStatus;
import net.ahm.member.profile.service.utils.EncryptUtils;
import net.ahm.member.profile.service.utils.MemberConstants;
import net.ahm.member.profile.service.utils.MemberUtils;

@Component
@RestController
@RequestMapping("/app/v1")
@Slf4j
public class MemberService {
	private static final String INVALID_HEADERS = "{'httpStatusCode': 412, 'httpStatusDesc':'Mandatory elements not found in http headers'}";

	private static final String INVALID_CLIENT_APP = "{'httpStatusCode': 432, 'httpStatusDesc':'Invalid client app in http headers'}";

	@Autowired
	MemberDemographicHandler memberDemographicHandler;

	@Autowired
	MemberEligibilityHandler memberEligibilityHandler;

	@Autowired
	Environment env;

	////// member info APPI

	@GetMapping(value = "/PatientDemographic/search/{memberPlanID}", produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_FORM_URLENCODED_VALUE })
	public ResponseEntity<MemberDemographicSearchResponse> getMemberInfo(@RequestHeader HttpHeaders headers,
			HttpServletRequest request, @PathVariable long memberPlanID)
			throws IOException, MemberHeaderException, EligibilityException {

		long memberId = memberPlanID;
		String correlationID = headers.getFirst(MemberConstants.X_CORRELATION_ID);

		String clientApp = headers.getFirst(MemberConstants.CLIENT_APP);

		logRequester(request, headers);

		validationOfHeaders(correlationID, clientApp);

		MemberDemographicSearchResponse response = null;

		log.info(" X-Correlation-Id: " + correlationID
				+ " | Message : MemberDemographicSearch request received | MemberPlanId:  " + memberId);

		try {
			if (memberId > 0) {// from .net code we have used this condition

				
				response = memberDemographicHandler.processAction(correlationID, memberId);

				if (response != null) {

					return new ResponseEntity<>(response, HttpStatus.OK);

				} else {

					MemberStatus memberStatusRec = new MemberStatus();
					memberStatusRec.setStatusCode(10010);
					memberStatusRec.setStatusDesc(MemberConstants.STATUS_10010);
					response = new MemberDemographicSearchResponse();
					response.setStatusRec(memberStatusRec);
					log.info("X-Correlation-Id: " + correlationID + " | Response Payload: "
							+ EncryptUtils.encryptString(response.toString()) + " | MemberPlanId:  " + memberId);

					return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);// not
																				// found
				}
			} else {
				MemberStatus memberStatusRec = new MemberStatus();
				memberStatusRec.setStatusCode(10040);
				memberStatusRec.setStatusDesc(MemberConstants.STATUS_10040);

				response = new MemberDemographicSearchResponse();
				response.setStatusRec(memberStatusRec);
				log.info("X-Correlation-Id: " + correlationID + " | Message: Invalid MemberPlanId"
						+ EncryptUtils.encryptString(response.toString()) + " | MemberPlanId:  " + memberId);
				return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);

			}

		} catch (Exception e) {
			log.error("X-Correlation-Id: " + correlationID + " | " + e.getMessage() + " | MemberPlanId:  " + memberId
			);
			response = new MemberDemographicSearchResponse();

			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);

		}

	}

	@PostMapping(value = "/member/eligibility/search", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<MemberEligibilityResponse> MemberEligibilityForMember(@RequestHeader HttpHeaders headers,
			HttpServletRequest request, @Valid @RequestBody MemberEligibilityRequest memberEligibilityRequest)
			throws IOException, MemberHeaderException, EligibilityException {

		String correlationID = headers.getFirst(MemberConstants.X_CORRELATION_ID);

		String clientApp = headers.getFirst(MemberConstants.CLIENT_APP);

		logRequester(request, headers);

		validationOfHeaders(correlationID, clientApp);

		log.info(("X-Correlation-Id: " + correlationID + " | MemberEligibilityRequest: "
				+ EncryptUtils.encryptString(memberEligibilityRequest.toString())));

		MemberEligibilityResponse response = null;

		try {

			if ((validateEligibilityRequest(memberEligibilityRequest.getFirstName(),
					memberEligibilityRequest.getLastName(), memberEligibilityRequest.getDob()))) {

				String firstName = memberEligibilityRequest.getFirstName();
				String lastName = memberEligibilityRequest.getLastName();
				if (firstName.length() >= 2 && lastName.length() >= 2) {

					response = memberEligibilityHandler.processAction(memberEligibilityRequest, correlationID);
					if (response != null) {

						return new ResponseEntity<>(response, HttpStatus.OK);

					} else {
						response = new MemberEligibilityResponse();

						MemberStatus memberStatusRec = new MemberStatus();
						memberStatusRec.setStatusCode(10010);
						memberStatusRec.setStatusDesc(MemberConstants.STATUS_10010);
						response.setStatusRec(memberStatusRec);
						log.info("X-Correlation-Id: " + correlationID + "Response Payload: "
								+ EncryptUtils.encryptString(response.toString()));

						return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);

					}
				} else {
					response = new MemberEligibilityResponse();
					MemberStatus memberStatusRec = new MemberStatus();
					memberStatusRec.setStatusCode(10040);
					memberStatusRec.setStatusDesc(MemberConstants.STATUS_10040);
					response.setStatusRec(memberStatusRec);
					log.info(("X-Correlation-Id: " + correlationID + " | Response Payload: "
							+ EncryptUtils.encryptString(response.toString())));

					// response.setStatusRec(10040,
					// MemberConstants.STATUS_10040);
					return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);

				}
			} else {
				response = new MemberEligibilityResponse();
				MemberStatus memberStatusRec = new MemberStatus();
				memberStatusRec.setStatusCode(10002);
				memberStatusRec.setStatusDesc(MemberConstants.STATUS_10002);
				response.setStatusRec(memberStatusRec);
				log.info(("X-Correlation-Id: " + correlationID + " | Response Payload: "
						+ EncryptUtils.encryptString(response.toString())));

				return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
			}

		} catch (Exception e) {
			log.error("X-Correlation-Id: " + correlationID + " | " + e.getMessage());
			response = new MemberEligibilityResponse();
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);

		}

	}

	private boolean validateEligibilityRequest(String fName, String lName, String dob) {
		if (fName != null && lName != null && dob != null) {

			if (isDateValid(dob) && !dob.equals(MemberConstants.DATE_MIN_VALUE)) {

				return true;
			}

		}

		return false;

	}

	boolean isDateValid(String date) {
		try {

			DateFormat df = new SimpleDateFormat(MemberConstants.DATE_FORMAT);
			df.setLenient(false);
			df.parse(date);
			return true;
		} catch (ParseException e) {

			return false;
		}
	}

	public void validationOfHeaders(String correlationID, String clientApp)
			throws MemberHeaderException, EligibilityException {

		if (correlationID == null || clientApp == null) {
			log.info("X-Correlation-Id: " + correlationID + " | Message: correlationID or clientApp is null");

			throw new EligibilityException(INVALID_HEADERS);

		}

		if (!clientApp.equals("EPIC")) {
			
			log.info("X-Correlation-Id: " + correlationID + " | Message: Invalid clientApp");
			throw new MemberHeaderException(INVALID_CLIENT_APP);

		}

	}

	private void logRequester(HttpServletRequest request, HttpHeaders headers) {
		String correlationID = headers.getFirst(MemberConstants.X_CORRELATION_ID);
		try {
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			String currentPrincipalName = authentication.getName();
			AuthorizationLogElements authLog = new AuthorizationLogElements("Request", "", request.getRemoteHost(),
					request.getLocalAddr(),
					String.format("Endpoint: %s - client-app : %s - x-correlation-id : %s",
							this.getClass().getSimpleName(), request.getHeader("client-app"),
							request.getHeader("x-correlation-id")),
					request.getHeader("User-Agent"), request.getHeader("referer"));
			authLog.setUser(currentPrincipalName);

			MemberUtils.logAuthorationInfo(this.getClass().getSimpleName() + " " + authLog.toString());
			log.info("X-Correlation-Id: " + correlationID + " | "
					+ (String.format("Headers: %s", EncryptUtils.encryptString(headers.toString()))));
		} catch (Exception e) {
			log.error("Error: " + e.getMessage());
		}
	}

}
