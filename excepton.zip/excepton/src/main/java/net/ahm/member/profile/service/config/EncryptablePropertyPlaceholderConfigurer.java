package net.ahm.member.profile.service.config;

import java.io.IOException;
import java.util.Properties;

import org.jasypt.exceptions.EncryptionOperationNotPossibleException;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.EnumerablePropertySource;
import org.springframework.core.env.Environment;
import org.springframework.core.env.PropertySource;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
import net.ahm.member.profile.service.utils.EncryptUtils;
import net.ahm.member.profile.service.utils.MemberConstants;

@Component
@Slf4j
public class EncryptablePropertyPlaceholderConfigurer extends PropertySourcesPlaceholderConfigurer {

	private ConfigurableEnvironment environment;

	@Override
	public void setEnvironment(Environment environment) {
		super.setEnvironment(environment);
		this.environment = (ConfigurableEnvironment) environment;
	}

	@Override
	protected void loadProperties(Properties props) throws IOException {
		this.localOverride = true;
		for (PropertySource<?> propertySource : environment.getPropertySources()) {
			if (propertySource instanceof EnumerablePropertySource) {
				String[] propertyNames = ((EnumerablePropertySource<?>) propertySource).getPropertyNames();
				for (String propertyName : propertyNames) {
					String propertyValue = environment.getProperty(propertyName);
					if (propertyValue.startsWith(MemberConstants.DES_PREFIX)) {
						String aesEncryption = propertyValue.replace(MemberConstants.DES_PREFIX,
								MemberConstants.AES_PREFIX);
						try {
							String decryptedValue = EncryptUtils.decryptString(aesEncryption);
							props.setProperty(propertyName, decryptedValue);
						} catch (EncryptionOperationNotPossibleException e) {
							log.error("Could not decrypt : Property = " + propertyName, e);
						}
					}
				}
			}
		}
	}
}
