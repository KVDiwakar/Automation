package net.ahm.member.profile.service.exception;

public class MemberException extends Exception {

	/**
	 * @author n097116
	 *
	 */
	private static final long serialVersionUID = 3581065754853580226L;

	public MemberException() {
		super();
	}

	public MemberException(String message) {
		super(message);
	}

	public MemberException(String message, Throwable cause) {
		super(message, cause);
	}

	public MemberException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public MemberException(Throwable cause) {
		super(cause);
	}

}
