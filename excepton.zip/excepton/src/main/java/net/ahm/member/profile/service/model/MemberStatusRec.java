package net.ahm.member.profile.service.model;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import net.ahm.member.profile.service.utils.MemberConstants;

@Data
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MemberStatusRec {

	private int statusCode;
	private String statusDesc;
	private String severityLevel;

	public MemberStatusRec() {
		this.statusCode = 10000;
		this.statusDesc = "Successful";
		this.severityLevel = MemberConstants.STATUS_NONE;
	}

	public MemberStatusRec(int statusCode, String statusDesc) {
		this.statusCode = statusCode;
		this.statusDesc = statusDesc;
		this.severityLevel = MemberConstants.STATUS_NONE;
	}

	public int getstatusCode() {
		return statusCode;
	}

	public void setstatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public void setstatusCode(String statusCode) {

		this.statusCode = Integer.parseInt(statusCode);
	}

	public String getstatusDesc() {
		return statusDesc;
	}

	public void setstatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public void setStatusRec(int statusCode, String statusDesc) {
		this.setstatusCode(statusCode);
		this.setstatusDesc(statusDesc);
		switch (statusCode) {
		case 10004:
		case 10002:
		case 10040:
		case 10010:
		case 412:
		case 432:
			this.setseverityLevel(SeverityLevel.LOW.toString());
			break;
		case 500:
		case 20000:
			this.setseverityLevel(SeverityLevel.HIGH.toString());
			break;
		case 61001:
			this.setstatusCode(10010);
			this.setstatusDesc(MemberConstants.STATUS_10010);
			this.setseverityLevel(SeverityLevel.LOW.toString());
			break;
		default:
			this.setseverityLevel(MemberConstants.STATUS_NONE);
		}

	}

	public String getseverityLevel() {
		return severityLevel;
	}

	public void setseverityLevel(String level) {
		this.severityLevel = level;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class MemberStatusRec {\n");
		sb.append("    statusCode: ").append(toIndentedString(statusCode)).append("\n");
		sb.append("    statusDesc: ").append(toIndentedString(statusDesc)).append("\n");
		sb.append("    severityLevel: ").append(toIndentedString(severityLevel)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

}
