package net.ahm.member.profile.service.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MemberEligibilityResponse {

	private List<MemberEligibility> memberEligibility;
	
	private MemberStatus statusRec;

	@Override
	public String toString() {
		return "MemberEligibilityResponse [memberEligibility=" + memberEligibility + ", statusRec=" + statusRec + "]";
	}

	
}
