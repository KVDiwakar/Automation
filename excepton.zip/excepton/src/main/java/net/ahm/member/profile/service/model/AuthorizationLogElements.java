package net.ahm.member.profile.service.model;

public class AuthorizationLogElements {
	private String timestamp = null;
	private String eventType = null;
	private String user = null;
	private String role = null;
	private String reason = null;
	private String sourceIP = null;
	private String destinationIP = null;
	private String description = null;
	private String browser = null;
	private String referrer = null;

	public AuthorizationLogElements() {
	}

	public AuthorizationLogElements(String eventType, String reason, String sourceIP, String destinationIP,
			String description, String browser, String referrer) {

		this.timestamp = new java.util.Date().toString();
		this.eventType = eventType;
		this.user = "";
		this.role = "";
		this.reason = reason;
		this.sourceIP = sourceIP;
		this.destinationIP = destinationIP;
		this.description = description;
		this.browser = browser;
		this.referrer = referrer;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public void setSourceIP(String sourceIP) {
		this.sourceIP = sourceIP;
	}

	public void setDestinationIP(String destinationIP) {
		this.destinationIP = destinationIP;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}

	public void setReferrer(String referrer) {
		this.referrer = referrer;
	}

	public String getTimestamp() {
		return this.timestamp;
	}

	public String getEventType() {
		return this.eventType;
	}

	public String getUser() {
		return this.user;
	}

	public String getRole() {
		return this.role;
	}

	public String getReason() {
		return this.reason;
	}

	public String getSourceIP() {
		return this.sourceIP;
	}

	public String getDestinationIP() {
		return this.destinationIP;
	}

	public String getDescription() {
		return this.description;
	}

	public String getBrowser() {
		return this.browser;
	}

	public String getReferrer() {
		return this.referrer;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("Timestamp: ").append(timestamp).append(" | ");
		sb.append("EventType : ").append(eventType).append(" | ");
		sb.append("User: ").append(user).append(" | ");
		sb.append("Role: ").append(role).append(" | ");
		sb.append("Reason: ").append(reason).append(" | ");
		sb.append("SourceIP: ").append(sourceIP).append(" | ");
		sb.append("DestinationIP: ").append(destinationIP).append(" | ");
		sb.append("Description: ").append(description).append(" | ");
		sb.append("Browser: ").append(browser).append(" | ");
		sb.append("Referrer: ").append(referrer).append(" | ");
		return sb.toString();
	}

}
