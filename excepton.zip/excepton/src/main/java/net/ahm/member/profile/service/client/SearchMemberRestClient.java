package net.ahm.member.profile.service.client;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.env.Environment;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import lombok.extern.slf4j.Slf4j;
import net.ahm.member.profile.service.model.ESLSearchIndividualRequest;
import net.ahm.member.profile.service.model.ESLSearchRequest;
import net.ahm.member.profile.service.model.ESLSearchResponse;
import net.ahm.member.profile.service.utils.MemberConstants;
import reactor.core.publisher.Mono;

@Service
@Slf4j
public class SearchMemberRestClient {

	@Autowired
	WebClient webClient;

	@Autowired
	OAuth2RestTemplate oAuth2RestTemplate;

	@Value(MemberConstants.ESLAPI_URL)
	String uri;

	@Value(MemberConstants.IDSOURCE)
	String idsource;

	@Autowired
	Environment env;

	public ESLSearchResponse getAPIResponse(ESLSearchIndividualRequest personSearchRequest)
			throws InterruptedException, ExecutionException {

		ESLSearchResponse req;
		Map<String, String> uriVariables = new HashMap<>();
		String value = oAuth2RestTemplate.getAccessToken().getValue();

		log.info("ESL Request start: " + personSearchRequest.getIndividualSearch().toString().replace("\n", " "));

		req = webClient.post().uri(uri, uriVariables).headers(httpHeaders -> {
			httpHeaders.setBearerAuth(value);
			httpHeaders.set(MemberConstants.X_CVS_CONSUMER_CORRELATION_ID,
					personSearchRequest.getxCVSConsumerCorrelationId());
		}).body(Mono.just(personSearchRequest.getIndividualSearch()), ESLSearchRequest.class).retrieve()
				.bodyToMono(new ParameterizedTypeReference<ESLSearchResponse>() {
				}).toFuture().get();

		log.info("ESL Response: " + req.toString().replace("\n", " "));

		return req;
	}
}
