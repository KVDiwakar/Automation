package net.ahm.member.profile.service.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

import net.ahm.member.profile.service.utils.EncryptUtils;
import net.ahm.member.profile.service.utils.MemberConstants;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	@Value(MemberConstants.SECUREUSER)
	String userid;
	@Value(MemberConstants.SECUREPASSWORD)
	String passwd;

	@Override
	public void configure(HttpSecurity http) throws Exception {
		http.csrf().disable().authorizeRequests().antMatchers("/v1/**","/app/v1/**").authenticated().and().httpBasic();
	}
	
	


	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.inMemoryAuthentication().withUser(userid).password("{noop}" + EncryptUtils.decryptString(passwd))
				.roles("USER");
	}

}

