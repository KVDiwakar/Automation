package net.ahm.member.profile.service.handler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
import net.ahm.member.profile.service.client.SearchMemberRestClient;
import net.ahm.member.profile.service.model.CrosswalkSearchRequest;
import net.ahm.member.profile.service.model.CrosswalkSearchResponse;
import net.ahm.member.profile.service.model.ESLIndividualSearchRequest;
import net.ahm.member.profile.service.model.ESLSearchIndividualRequest;
import net.ahm.member.profile.service.model.ESLSearchRequest;
import net.ahm.member.profile.service.model.ESLSearchResponse;
import net.ahm.member.profile.service.model.ESLSourceSystemIdentfierResponse;
import net.ahm.member.profile.service.model.ESLSourceSystemIdentifierRequest;
import net.ahm.member.profile.service.model.ESLSourceSystemIdividualResponse;
import net.ahm.member.profile.service.utils.MemberConstants;

@Component("SeachMemberHandler")
@Slf4j
public class SearchMemberHandler {
	@Autowired
	SearchMemberRestClient searchMemberRestClient;

	@Value(MemberConstants.IDSOURCE)
	private String idsource;

	public ESLSearchIndividualRequest generatePersonSearchRequest(CrosswalkSearchRequest inReq) throws IOException {

		ESLIndividualSearchRequest mem = new ESLIndividualSearchRequest();
		List<String> sourceSystem = new ArrayList<>();
		sourceSystem.add("AH");

		ESLSourceSystemIdentifierRequest sId = new ESLSourceSystemIdentifierRequest(
				getOrgEslPrefix(inReq.getidType()) + "~" + inReq.getidValue());

		mem.sourceSystemIdentifierSearch(sId);
		mem.searchSourceSystem(sourceSystem);
		mem.setReturnType("KEY");
		mem.searchType("sourceSystemKey");
		ESLSearchRequest outReq = new ESLSearchRequest();
		outReq.setIndividualSearch(mem);
		ESLSearchIndividualRequest req = new ESLSearchIndividualRequest();
		req.setIndividualSearch(outReq);
		req.setxCVSConsumerCorrelationId(inReq.getxCorrelationId());
		return req;
	}

	// TO-DO store the logic for all kinds of ORG IDS
	private String getOrgEslPrefix(String idType) {
		if (idType.equals(MemberConstants.DIGITAL_ID))
			return "9050";

		if (idType.equals("AH"))
			return idsource.replace("~", "");

		return "6002";
	}

	public String toJsonString(Object ob) {

		ObjectMapper mapper = new ObjectMapper();
		try {
			return mapper.writeValueAsString(ob);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}

		return "Couldn't map to string";
	}

	public CrosswalkSearchResponse findMemPlanId(CrosswalkSearchRequest req) throws IOException {

		CrosswalkSearchResponse respon = new CrosswalkSearchResponse();
		ESLSearchIndividualRequest eslreq = generatePersonSearchRequest(req);

		int idCount = 0;
		// TO-DO Make call to db or ESL to seach the member planids
		try {
			ESLSearchResponse search = callESLMemberAPI(eslreq);
			if (search.getHttpCode() != null) {
				respon.setStatusRec(Integer.parseInt(search.getHttpCode()), search.getHttpMessage());
			} else {
				for (ESLSourceSystemIdividualResponse responseItem : search.getIndividualList().getIndividual()) {
					for (ESLSourceSystemIdentfierResponse item : responseItem.getSourceSystemIndividual()) {
						String[] items = item.getIndividualIdentifier().getresourceId().split("~");
						if (items[0].equals(idsource.replace("~", ""))) {
							respon.setPlanid(Long.parseLong(items[1]));
							idCount++;
						}
					}
				}
			}
		} catch (ExecutionException e) {
			respon.setStatusRec(10004, MemberConstants.STATUS_10004);
			return respon;
		} catch (InterruptedException e) {
			respon.setStatusRec(10004, MemberConstants.STATUS_10004);
			return respon;
		}
		if (idCount == 0)
			respon.setStatusRec(10010, MemberConstants.STATUS_10010);

		return respon;
	}

	private ESLSearchResponse callESLMemberAPI(ESLSearchIndividualRequest personSearchRequest)
			throws InterruptedException, ExecutionException {
		return searchMemberRestClient.getAPIResponse(personSearchRequest);
	}

	public void setidsource(String value) {
		this.idsource = value;
	}

}
