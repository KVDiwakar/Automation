package net.ahm.member.profile.service.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;
import net.ahm.member.profile.service.handler.SearchMemberHandler;
import net.ahm.member.profile.service.model.AuthorizationLogElements;
import net.ahm.member.profile.service.model.CrosswalkSearchRequest;
import net.ahm.member.profile.service.model.CrosswalkSearchResponse;
import net.ahm.member.profile.service.utils.EncryptUtils;
import net.ahm.member.profile.service.utils.MemberConstants;
import net.ahm.member.profile.service.utils.MemberUtils;

@Component
@RestController
@RequestMapping("/v1/individuals")
@Slf4j
public class IndividualSearch {

	@Autowired
	SearchMemberHandler searchMemberHandler;

	@Value(MemberConstants.SERVER_ENV)
	private String serverEnv;

	public void setserverEnv(String value) {
		this.serverEnv = value;
	}

	@GetMapping(value = "/crosswalk", produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_FORM_URLENCODED_VALUE })
	public ResponseEntity<CrosswalkSearchResponse> getMem(@RequestHeader HttpHeaders headers,
			HttpServletRequest request, @RequestParam String idValue, @RequestParam String idType,
			@RequestParam String searchScope) throws IOException {

		CrosswalkSearchRequest individualSearchReq = new CrosswalkSearchRequest();
		String correlationID;
		String clientApp;

		logRequester(request, headers);
		CrosswalkSearchResponse respon = new CrosswalkSearchResponse();
		correlationID = headers.getFirst(MemberConstants.X_CORRELATION_ID);
		clientApp = headers.getFirst(MemberConstants.CLIENT_APP);
		String requestInfo = String.format("CorrelationiID: %s ClientApp: %s", correlationID, clientApp);

		if (validHeaders(correlationID, clientApp)) {
			if (clientApp != null && !clientApp.equals("CE"))
				respon.setStatusRec(432, MemberConstants.STATUS_432);
			else
				respon.setStatusRec(412, MemberConstants.STATUS_412);
			log.error(requestInfo);

			return new ResponseEntity<>(respon, HttpStatus.BAD_REQUEST);
		}

		if (validValues(idType, idValue, searchScope)) {
			respon.setStatusRec(10040, MemberConstants.STATUS_10040);
			log.error(requestInfo);
			return new ResponseEntity<>(respon, HttpStatus.BAD_REQUEST);
		}

		individualSearchReq.setidValue(idValue);
		individualSearchReq.setidType(idType);
		individualSearchReq.setsearchScope(searchScope);
		individualSearchReq.setxCorrelationId(correlationID);

		respon = searchMemberHandler.findMemPlanId(individualSearchReq);

		log.info("request successful: " + individualSearchReq.toString());
		return new ResponseEntity<>(respon, HttpStatus.OK);
	}

	@PostMapping(value = "/decrypt", produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_FORM_URLENCODED_VALUE })
	public String getDecyptedData(@RequestHeader HttpHeaders headers, @RequestParam String data,
			@RequestParam String encrypt) throws IOException {

		if ("PRODPRD".contains(serverEnv.toUpperCase()))
			return MemberConstants.STATUS_DECRYPT;

		String result = "";
		if (encrypt.equals("true")) {
			result = EncryptUtils.encryptString(data).replace(MemberConstants.AES_PREFIX, MemberConstants.DES_PREFIX);
		} else {
			result = data.startsWith(MemberConstants.DES_PREFIX)
					? EncryptUtils.decryptString(data.replace(MemberConstants.DES_PREFIX, MemberConstants.AES_PREFIX))
					: EncryptUtils.decryptString(String.format(MemberConstants.DES_PREFIX + "%s)", data));
		}
		return result;
	}

	private boolean validHeaders(String correlationID, String clientApp) {
		return correlationID == null || clientApp == null || !clientApp.equals("CE");
	}

	private boolean validValues(String idType, String idValue, String searchScope) {
		return idType == null || idValue == null || searchScope == null
				|| (!idType.equals(MemberConstants.DIGITAL_ID) && !idType.equals(MemberConstants.AHM_ID))
				|| !searchScope.contentEquals("AH");
	}

	private void logRequester(HttpServletRequest request, HttpHeaders headers) {
		try {
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			String currentPrincipalName = authentication.getName();
			AuthorizationLogElements authLog = new AuthorizationLogElements("Request", "", request.getRemoteHost(),
					request.getLocalAddr(),
					String.format("Endpoint: %s - client-app : %s - x-correlation-id : %s",
							this.getClass().getSimpleName(), request.getHeader("client-app"),
							request.getHeader("x-correlation-id")),
					request.getHeader("User-Agent"), request.getHeader("referer"));
			authLog.setUser(currentPrincipalName);

			MemberUtils.logAuthorationInfo(this.getClass().getSimpleName() + " " + authLog.toString());
			log.info(String.format("Headers: %s", headers));
		} catch (Exception e) {
			log.error("Error: " + e.getMessage());
		}
	}

}
