package net.ahm.member.profile.service.config;

import java.util.Arrays;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.security.oauth2.client.AuthorizedClientServiceReactiveOAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.DefaultOAuth2ClientContext;
import org.springframework.security.oauth2.client.InMemoryReactiveOAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.InMemoryReactiveClientRegistrationRepository;
import org.springframework.security.oauth2.client.registration.ReactiveClientRegistrationRepository;
import org.springframework.security.oauth2.client.token.AccessTokenProvider;
import org.springframework.security.oauth2.client.token.AccessTokenProviderChain;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsAccessTokenProvider;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.security.oauth2.client.token.grant.code.AuthorizationCodeAccessTokenProvider;
import org.springframework.security.oauth2.client.token.grant.implicit.ImplicitAccessTokenProvider;
import org.springframework.security.oauth2.client.token.grant.password.ResourceOwnerPasswordAccessTokenProvider;
import org.springframework.security.oauth2.client.web.reactive.function.client.ServerOAuth2AuthorizedClientExchangeFilterFunction;
import org.springframework.security.oauth2.core.AuthorizationGrantType;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import net.ahm.member.profile.service.utils.EncryptUtils;
import net.ahm.member.profile.service.utils.MemberConstants;
import reactor.netty.http.client.HttpClient;
import reactor.netty.tcp.ProxyProvider;

@Configuration
public class MemberConfig {

	private String proxyHost;
	private String port;
	private boolean proxyEnabled;

	private String tokenUrl;
	private String clientId;
	private String clientSecret;
	private String grantType;
	private String scope;

	@Bean
	public OAuth2RestTemplate oAuth2RestTemplate() {
		ClientCredentialsResourceDetails resourceDetails = new ClientCredentialsResourceDetails();
		resourceDetails.setAccessTokenUri(tokenUrl);
		resourceDetails.setClientId(clientId);
		resourceDetails.setClientSecret(EncryptUtils.decryptString(clientSecret));
		resourceDetails.setGrantType(grantType);
		resourceDetails.setScope(Arrays.asList(scope));
		DefaultOAuth2ClientContext clientContext = new DefaultOAuth2ClientContext();
		OAuth2RestTemplate oAuth2RestTemplate = new OAuth2RestTemplate(resourceDetails, clientContext);
		// Instantiate a new HTPP client with PROXY configuration
		HttpClientBuilder httpClientBuilder = withProxyClients(proxyEnabled);

		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(
				httpClientBuilder.build());
		ClientCredentialsAccessTokenProvider clientCredentialsAccessTokenProvider = new ClientCredentialsAccessTokenProvider();
		clientCredentialsAccessTokenProvider.setRequestFactory(requestFactory);
		// accessTokenProvider
		AccessTokenProvider accessTokenProvider = new AccessTokenProviderChain(Arrays.<AccessTokenProvider>asList(
				new AuthorizationCodeAccessTokenProvider(), new ImplicitAccessTokenProvider(),
				new ResourceOwnerPasswordAccessTokenProvider(), clientCredentialsAccessTokenProvider));
		oAuth2RestTemplate.setAccessTokenProvider(accessTokenProvider);

		return oAuth2RestTemplate;
	}

	@Bean
	public WebClient webClient() {

		HttpClient httpClient = withProxy(proxyEnabled);
		ClientHttpConnector connector = new ReactorClientHttpConnector(httpClient);
		return WebClient.builder().clientConnector(connector).build();
	}

	@Bean
	ReactiveClientRegistrationRepository getRegistration() {
		ClientRegistration registration = ClientRegistration.withRegistrationId(MemberConstants.CVS_ESL_EPH_API)
				.tokenUri(tokenUrl).clientId(clientId).clientSecret(clientSecret)
				.authorizationGrantType(AuthorizationGrantType.CLIENT_CREDENTIALS)
				.scope(Arrays.asList(scope.split(MemberConstants.REGEX_SPACE))).build();
		return new InMemoryReactiveClientRegistrationRepository(registration);
	}

	@Bean(name = "defaultWebClient")
	WebClient webClient(ReactiveClientRegistrationRepository clientRegistrations) {
		InMemoryReactiveOAuth2AuthorizedClientService authorizedClientService = new InMemoryReactiveOAuth2AuthorizedClientService(
				clientRegistrations);
		ServerOAuth2AuthorizedClientExchangeFilterFunction oauth2FilterFunction = new ServerOAuth2AuthorizedClientExchangeFilterFunction(
				new AuthorizedClientServiceReactiveOAuth2AuthorizedClientManager(clientRegistrations,
						authorizedClientService));

		oauth2FilterFunction.setDefaultClientRegistrationId(MemberConstants.CVS_ESL_EPH_API);
		HttpClient httpClient = withProxy(proxyEnabled);
		ClientHttpConnector connector = new ReactorClientHttpConnector(httpClient);
		return WebClient.builder().clientConnector(connector).filter(oauth2FilterFunction).build();
	}

	private HttpClient withProxy(boolean enabled) {
		return enabled
				? HttpClient.create().tcpConfiguration(tcpClient -> tcpClient.proxy(proxy -> proxy
						.type(ProxyProvider.Proxy.HTTP).host(proxyHost).port(Integer.valueOf(port)).build()))
				: HttpClient.create();
	}

	private HttpClientBuilder withProxyClients(boolean enabled) {
		return enabled ? HttpClients.custom().setProxy(new HttpHost(proxyHost, Integer.valueOf(StringUtils.trim(port))))
				: HttpClients.custom();
	}
	
	@Bean
	public ObjectMapper objectMapper() {
		ObjectMapper mapper = new  ObjectMapper();
		mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
		return  mapper;
		
	}

	@Value(MemberConstants.PROXYENABLED)
	public void setProxyEnabled(String proxyEnabled) {
		this.proxyEnabled = proxyEnabled.equals("true");
	}

	@Value(MemberConstants.AETNA_PROXY_HOST)
	public void setProxyHost(String proxyHost) {
		this.proxyHost = proxyHost;
	}

	@Value(MemberConstants.AETNA_PROXY_PORT)
	public void setPort(String port) {
		this.port = port;
	}

	@Value(MemberConstants.ESL_OAUTH2_TOKEN_URI)
	public void setTokenUrl(String tokenUrl) {
		this.tokenUrl = tokenUrl;
	}

	@Value(MemberConstants.ESL_OAUTH2_CLIENT_ID)
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	@Value(MemberConstants.ESL_OAUTH2_CLIENT_SECRET)
	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}

	@Value(MemberConstants.ESL_OAUTH2_GRANT_TYPE)
	public void setGrantType(String grantType) {
		this.grantType = grantType;
	}

	@Value(MemberConstants.ESL_OAUTH2_SCOPE)
	public void setScope(String scope) {
		this.scope = scope;
	}

}
